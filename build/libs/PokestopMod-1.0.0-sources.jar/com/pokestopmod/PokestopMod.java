package com.pokestopmod;

import com.pokestopmod.commands.PokestopCommand;
import com.pokestopmod.config.RewardConfig;
import com.pokestopmod.data.PokestopManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_3222;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PokestopMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("pokestopmod");
    private PokestopManager pokestopManager;

    @Override
    public void onInitialize() {
        // Load configs
        RewardConfig.load();
        // If you have a PokestopConfig: uncomment the next line
        // PokestopConfig.load();

        pokestopManager = new PokestopManager();

        // Register commands
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            PokestopCommand.register(dispatcher, pokestopManager);
        });

        // Register tick handler for bonus updates and particle rendering
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            pokestopManager.tickBonus(server);

            // Render particles for all online players
            for (class_3222 player : server.method_3760().method_14571()) {
                pokestopManager.renderNearbyPokestopParticles(player);
            }
        });

        LOGGER.info("Pokéstop Mod initialized!");
    }
}