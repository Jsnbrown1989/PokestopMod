package com.pokestopmod.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.pokestopmod.data.PokestopManager;
import net.luckperms.api.LuckPermsProvider;
import net.minecraft.class_2168;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class PokestopCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher, PokestopManager manager) {
        dispatcher.register(method_9247("pokestop")
                .then(method_9247("reload")
                        .requires(src -> src.method_9259(2) || hasLuckPermsPermission(src, "replenish.admin.reload"))
                        .executes(ctx -> {
                            manager.reload();
                            ctx.getSource().method_45068(class_2561.method_43470("Pokéstop configs reloaded."));
                            return 1;
                        }))
                .then(method_9247("claim")
                        .requires(src -> src.method_9259(0) || hasLuckPermsPermission(src, "replenish.player.claim"))
                        .executes(ctx -> manager.attemptClaim(ctx.getSource())))
                .then(method_9247("startbonus")
                        .requires(src -> src.method_9259(2) || hasLuckPermsPermission(src, "replenish.admin.bonus"))
                        .then(method_9244("minutes", IntegerArgumentType.integer(1))
                                .executes(ctx -> {
                                    int minutes = IntegerArgumentType.getInteger(ctx, "minutes");
                                    manager.startBonus(ctx.getSource().method_9211(), minutes);
                                    ctx.getSource().method_45068(class_2561.method_43470("🎉 Started Pokéstop Bonus Time for " + minutes + " minutes!"));
                                    return 1;
                                })))
                .then(method_9247("create")
                        .requires(src -> src.method_9259(2) || hasLuckPermsPermission(src, "replenish.admin.create"))
                        .then(method_9244("name", StringArgumentType.word())
                                .then(method_9244("tier", IntegerArgumentType.integer(1, 3))
                                        .then(method_9244("pos", class_2262.method_9698())
                                                .then(method_9244("radius", IntegerArgumentType.integer(1))
                                                        .executes(ctx -> {
                                                            String name = StringArgumentType.getString(ctx, "name");
                                                            int tier = IntegerArgumentType.getInteger(ctx, "tier");
                                                            class_2338 pos = class_2262.method_9696(ctx, "pos");
                                                            int radius = IntegerArgumentType.getInteger(ctx, "radius");
                                                            manager.createPokestop(name, tier, pos, radius);
                                                            ctx.getSource().method_45068(class_2561.method_43470("Created Pokéstop '" + name + "' (Tier " + tier + ") at " + pos + " with radius " + radius));
                                                            return 1;
                                                        }))))))
                .then(method_9247("delete")
                        .requires(src -> src.method_9259(2) || hasLuckPermsPermission(src, "replenish.admin.delete"))
                        .then(method_9244("name", StringArgumentType.word())
                                .executes(ctx -> {
                                    String name = StringArgumentType.getString(ctx, "name");
                                    manager.deletePokestop(name);
                                    ctx.getSource().method_45068(class_2561.method_43470("Deleted Pokéstop '" + name + "'."));
                                    return 1;
                                })))
        );
    }

    private static boolean hasLuckPermsPermission(class_2168 src, String node) {
        class_3222 player = src.method_44023();
        if (player == null) return false;
        return LuckPermsProvider.get().getUserManager()
                .getUser(player.method_5667())
                .getCachedData().getPermissionData()
                .checkPermission(node).asBoolean();
    }
}