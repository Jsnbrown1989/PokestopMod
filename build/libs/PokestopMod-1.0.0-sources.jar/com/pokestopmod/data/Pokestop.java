package com.pokestopmod.data;

import net.minecraft.class_2338;

public class Pokestop {
    public final String name;
    public final int tier;
    public final class_2338 position;
    public final int radius;

    public Pokestop(String name, int tier, class_2338 position, int radius) {
        this.name = name;
        this.tier = tier;
        this.position = position;
        this.radius = radius;
    }

    public boolean isWithin(class_2338 playerPos) {
        return playerPos.method_10262(position) <= radius * radius;
    }
}
