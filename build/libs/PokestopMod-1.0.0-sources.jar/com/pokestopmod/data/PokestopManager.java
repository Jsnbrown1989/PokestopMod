package com.pokestopmod.data;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pokestopmod.PokestopMod;
import com.pokestopmod.config.PokestopConfig;
import com.pokestopmod.config.RewardConfig;
import com.pokestopmod.util.ParticleUtil;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.*;

public class PokestopManager {
    private final File configFile = new File("config/pokestop/locations.json");
    private final Map<String, Pokestop> pokestops = new HashMap<>();
    private final CooldownDatabase db = new CooldownDatabase();
    private final Map<String, Float> pokestopAngles = new HashMap<>(); // Track rotation per Pokéstop

    private boolean bonusActive = false;
    private long bonusEndTime = 0;
    private long bonusStartTime = 0;
    private long lastReminderMinute = -1;

    public PokestopManager() {
        reload();
    }

    public void reload() {
        try {
            if (!configFile.exists()) {
                configFile.getParentFile().mkdirs();
                configFile.createNewFile();
                save();
            }

            Gson gson = new Gson();
            Type type = new TypeToken<Map<String, Pokestop>>() {}.getType();
            Map<String, Pokestop> loaded = gson.fromJson(new FileReader(configFile), type);
            if (loaded != null) {
                pokestops.clear();
                pokestops.putAll(loaded);
            }
        } catch (Exception e) {
            PokestopMod.LOGGER.error("Failed to load pokestop/locations.json", e);
        }
    }

    public void save() {
        try (FileWriter writer = new FileWriter(configFile)) {
            new Gson().toJson(pokestops, writer);
        } catch (Exception e) {
            PokestopMod.LOGGER.error("Failed to save pokestop/locations.json", e);
        }
    }

    public void createPokestop(String name, int tier, class_2338 pos, int radius) {
        Pokestop stop = new Pokestop(name, tier, pos, radius);
        pokestops.put(name, stop);
        save();
    }

    public void deletePokestop(String name) {
        pokestops.remove(name);
        save();
    }

    public int attemptClaim(class_2168 source) {
        class_3222 player = source.method_44023();
        class_2338 playerPos = player.method_24515();
        for (Pokestop stop : pokestops.values()) {
            if (stop.isWithin(playerPos)) {
                long cooldownMillis = PokestopConfig.claimCooldownMillis;
                Long lastClaim = db.getLastClaim(player.method_5667(), stop.name);

                if (lastClaim != null) {
                    long elapsed = System.currentTimeMillis() - lastClaim;
                    if (elapsed < cooldownMillis) {
                        long remaining = cooldownMillis - elapsed;
                        String formatted = formatMillis(remaining);
                        source.method_45068(class_2561.method_43470("You must wait " + formatted + " before claiming this Pokéstop again."));
                        return 0;
                    }
                }

                triggerReward(player, stop.tier);
                db.setClaim(player.method_5667(), stop.name, System.currentTimeMillis());
                source.method_45068(class_2561.method_43470("You claimed " + stop.name + "!"));
                return 1;
            }
        }
        source.method_45068(class_2561.method_43470("You are not within a Pokéstop radius."));
        return 0;
    }

    private boolean onCooldown(UUID playerId, String stopName) {
        Long last = db.getLastClaim(playerId, stopName);
        return last != null && (System.currentTimeMillis() - last < PokestopConfig.claimCooldownMillis);
    }

    private void triggerReward(class_3222 player, int tier) {
        List<String> commands = RewardConfig.getCommandsForTier(tier);
        List<String> globalCommands = RewardConfig.getGlobalCommandsForTier(tier);

        int multiplier = bonusActive ? 2 : 1;

        for (int i = 0; i < (3 * multiplier); i++) {
            class_1799 selected = RewardConfig.getRandomWeightedItemForTier(tier);
            if (!selected.method_7960()) {
                player.method_7270(selected.method_7972());
            }
        }

        // Player-specific commands
        for (String command : commands) {
            String parsed = command.replace("{player}", player.method_7334().getName());
            player.method_5682().method_3734().method_44252(
                    player.method_5682().method_3739(), parsed
            );
        }

        // Global commands (always run)
        for (String command : globalCommands) {
            String parsed = command.replace("{player}", player.method_7334().getName());
            player.method_5682().method_3734().method_44252(
                    player.method_5682().method_3739(), parsed
            );
        }
    }

    private String formatMillis(long millis) {
        long seconds = millis / 1000;
        long minutes = seconds / 60;
        long remainingSeconds = seconds % 60;
        if (minutes > 0) {
            return minutes + "m " + remainingSeconds + "s";
        } else {
            return remainingSeconds + "s";
        }
    }

    public void renderNearbyPokestopParticles(class_3222 player) {
        if (!(player.method_37908() instanceof net.minecraft.class_3218 world)) return;
        class_2338 playerPos = player.method_24515();

        for (Pokestop stop : pokestops.values()) {
            double distance = stop.position.method_10262(playerPos);
            int effectiveRadius = stop.radius + 16; // visibility buffer

            if (distance <= effectiveRadius * effectiveRadius) {
                float angle = pokestopAngles.getOrDefault(stop.name, 0.0f) + 10.0f;
                if (angle >= 360.0f) angle -= 360.0f;
                pokestopAngles.put(stop.name, angle);

                boolean canClaim = !onCooldown(player.method_5667(), stop.name);
                ParticleUtil.drawRotatingParticle(world, stop, angle, canClaim);
            }
        }
    }

    public void startBonus(MinecraftServer server, int minutes) {
        bonusActive = true;
        bonusStartTime = System.currentTimeMillis();
        bonusEndTime = bonusStartTime + (minutes * 60 * 1000L);
        lastReminderMinute = -1;

        for (class_3222 player : server.method_3760().method_14571()) {
            player.method_7353(class_2561.method_43470("🎉 Pokéstop Bonus Time has started! All rewards are boosted for " + minutes + " minutes!"), false);
        }
    }

    public void tickBonus(MinecraftServer server) {
        if (bonusActive) {
            long remaining = bonusEndTime - System.currentTimeMillis();
            if (remaining <= 0) {
                bonusActive = false;
                for (class_3222 player : server.method_3760().method_14571()) {
                    player.method_7353(class_2561.method_43470("⏰ Pokéstop Bonus Time has ended."), false);
                }
            } else {
                long minutesLeft = (remaining / 1000) / 60;
                if (minutesLeft != lastReminderMinute && minutesLeft > 0) {
                    lastReminderMinute = minutesLeft;
                    for (class_3222 player : server.method_3760().method_14571()) {
                        player.method_7353(class_2561.method_43470("⏳ Pokéstop Bonus Time: " + minutesLeft + " minute(s) left!"), false);
                    }
                }
            }
        }
    }
}