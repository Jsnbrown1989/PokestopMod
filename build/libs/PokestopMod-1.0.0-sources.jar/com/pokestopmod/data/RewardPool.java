package com.pokestopmod.data;

import java.util.List;
import java.util.Random;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class RewardPool {
    public static List<class_1799> getItemsForTier(int tier) {
        return switch (tier) {
            case 1 -> List.of(new class_1799(class_1802.field_8279), new class_1799(class_1802.field_8600));
            case 2 -> List.of(new class_1799(class_1802.field_8620), new class_1799(class_1802.field_8463));
            case 3 -> List.of(new class_1799(class_1802.field_8477), new class_1799(class_1802.field_8288));
            default -> List.of();
        };
    }

    public static List<class_1799> getPreviewItems(int tier) {
        return getItemsForTier(tier);
    }
}
