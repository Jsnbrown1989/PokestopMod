package com.pokestopmod.util;

import com.pokestopmod.config.ParticleColorConfig;
import com.pokestopmod.data.Pokestop;
import net.minecraft.class_2338;
import net.minecraft.class_2390;
import net.minecraft.class_3218;
import org.joml.Vector3f;

/**
 * Utility for rendering rotating Pokéstop particles with customizable colors,
 * vertical bounce, and a simplified dust-only glow trail.
 */
public class ParticleUtil {

    public static void drawRotatingParticle(class_3218 world, Pokestop stop, float angleDegrees, boolean canClaim) {
        Vector3f color = ParticleColorConfig.getColorFor(stop.tier, canClaim);

        class_2390 mainParticle = new class_2390(color, 1.0f);
        class_2390 trailParticle = new class_2390(color, 0.4f); // smaller/fainter

        class_2338 center = stop.position;
        int radius = stop.radius;

        double rad = Math.toRadians(angleDegrees);
        double x = center.method_10263() + radius * Math.cos(rad);
        double z = center.method_10260() + radius * Math.sin(rad);

        double baseY = center.method_10264() + 1.0;
        double bounce = Math.sin(Math.toRadians(angleDegrees * 4)) * 0.5;
        double y = baseY + bounce;

        // Main particle
        world.method_14199(mainParticle, x + 0.5, y, z + 0.5, 1, 0, 0, 0, 0);

        // Simplified dust trail (3 steps)
        int trailSteps = 3;
        for (int i = 1; i <= trailSteps; i++) {
            double trailRadius = radius * (1.0 - (i * 0.15));
            double trailX = center.method_10263() + trailRadius * Math.cos(rad);
            double trailZ = center.method_10260() + trailRadius * Math.sin(rad);
            double trailY = y - (i * 0.05); // slight taper

            world.method_14199(trailParticle, trailX + 0.5, trailY, trailZ + 0.5, 1, 0, 0, 0, 0);
        }
    }
}