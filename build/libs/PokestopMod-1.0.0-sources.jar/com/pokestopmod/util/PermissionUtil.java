package com.pokestopmod.util;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.query.QueryOptions;
import net.minecraft.class_2168;

public class PermissionUtil {
    public static boolean hasPermission(class_2168 source, String node) {
        if (source.method_9259(4)) return true;
        try {
            var lp = LuckPermsProvider.get();
            var user = lp.getUserManager().getUser(source.method_44023().method_5667());
            if (user == null) return false;
            var queryOptions = lp.getContextManager().getQueryOptions(user).orElse(null);
            return user.getCachedData().getPermissionData(queryOptions).checkPermission(node).asBoolean();
        } catch (Exception e) {
            return false;
        }
    }
}
